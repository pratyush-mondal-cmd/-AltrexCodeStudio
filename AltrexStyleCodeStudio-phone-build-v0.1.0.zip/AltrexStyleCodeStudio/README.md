# Code Studio — Android starter

A dark, mobile-first coding workspace inspired by modern desktop AI coding environments.

## Included in v0.1.0 starter
- Dark workspace UI
- Project/file sidebar
- Code editor area
- AI assistant panel (demo mode)
- Settings entry point
- Kotlin + Jetpack Compose Android project

## Planned next
1. Persistent projects and file creation/rename/delete
2. Syntax highlighting and search
3. HTML/CSS/JS live preview
4. Real AI provider integration (user API key / OpenAI-compatible endpoint)
5. Secure key storage
6. Terminal-like command runner where Android permissions allow
7. ZIP import/export
8. APK/project export workflow where technically possible

## Build
Open the project in Android Studio and let Gradle sync. Then run the `app` configuration on an Android device/emulator.
