package com.example.codestudio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Bg = Color(0xFF0B0D12)
private val Panel = Color(0xFF11141B)
private val Panel2 = Color(0xFF171B23)
private val Accent = Color(0xFF7C5CFF)
private val Text = Color(0xFFE8EAF0)
private val Muted = Color(0xFF8B91A1)

data class CodeFile(val name: String, var content: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CodeStudioApp() }
    }
}

@Composable
fun CodeStudioApp() {
    var selected by remember { mutableStateOf("main.kt") }
    var code by remember {
        mutableStateOf("""fun main() {
    println("Hello from Code Studio!")
}

// Ask the AI panel to explain or improve this code.
""")
    }
    var aiPrompt by remember { mutableStateOf("") }
    var aiReply by remember { mutableStateOf("AI assistant ready. Add your API provider in Settings later.") }
    var showSettings by remember { mutableStateOf(false) }

    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Bg, surface = Panel, primary = Accent,
            onBackground = Text, onSurface = Text
        )
    ) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            Column {
                TopBar(onSettings = { showSettings = true })
                Row(Modifier.fillMaxSize()) {
                    FileSidebar(selected, onSelect = { selected = it })
                    Column(Modifier.weight(1f).fillMaxHeight()) {
                        EditorTabs(selected)
                        CodeEditor(code, onChange = { code = it }, Modifier.weight(1f))
                        BottomBar()
                    }
                    AiPanel(
                        prompt = aiPrompt,
                        reply = aiReply,
                        onPrompt = { aiPrompt = it },
                        onAsk = {
                            aiReply = "Demo mode: I would analyze your code and prompt here. Connect an AI provider/API key in Settings to get real responses."
                        }
                    )
                }
            }
        }

        if (showSettings) {
            AlertDialog(
                onDismissRequest = { showSettings = false },
                title = { Text("AI Settings") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("The starter supports an OpenAI-compatible provider architecture. Add the networking layer and your own key before release.")
                        Text("For safety, never hard-code a private API key into the APK.", color = Muted)
                    }
                },
                confirmButton = { TextButton(onClick = { showSettings = false }) { Text("Close") } }
            )
        }
    }
}

@Composable
fun TopBar(onSettings: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().height(56.dp).background(Panel),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Icon(Icons.Default.Code, null, tint = Accent, modifier = Modifier.padding(horizontal = 14.dp))
        Text("CODE STUDIO", fontSize = 16.sp, color = Text)
        Spacer(Modifier.weight(1f))
        IconButton(onClick = {}) { Icon(Icons.Default.PlayArrow, "Run", tint = Text) }
        IconButton(onClick = onSettings) { Icon(Icons.Default.Settings, "Settings", tint = Text) }
    }
}

@Composable
fun FileSidebar(selected: String, onSelect: (String) -> Unit) {
    val files = listOf("main.kt", "index.html", "style.css", "script.js", "README.md")
    Column(
        Modifier.width(155.dp).fillMaxHeight().background(Panel),
        verticalArrangement = Arrangement.Top
    ) {
        Text("PROJECT", color = Muted, fontSize = 11.sp, modifier = Modifier.padding(12.dp))
        files.forEach { name ->
            Row(
                Modifier.fillMaxWidth()
                    .background(if (name == selected) Panel2 else Color.Transparent)
                    .clickable { onSelect(name) }
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.Description, null, tint = if (name == selected) Accent else Muted,
                    modifier = Modifier.size(17.dp))
                Spacer(Modifier.width(8.dp))
                Text(name, color = Text, fontSize = 12.sp)
            }
        }
    }
}

@Composable
fun EditorTabs(selected: String) {
    Row(Modifier.fillMaxWidth().height(38.dp).background(Panel2), verticalAlignment = Alignment.CenterVertically) {
        Text("  $selected  ×", color = Text, fontSize = 12.sp)
    }
}

@Composable
fun CodeEditor(code: String, onChange: (String) -> Unit, modifier: Modifier) {
    Row(modifier.background(Bg).padding(10.dp)) {
        Text("1\n2\n3\n4\n5\n6\n7", color = Color(0xFF555B6B), fontSize = 12.sp, lineHeight = 20.sp)
        Spacer(Modifier.width(12.dp))
        BasicTextField(
            value = code,
            onValueChange = onChange,
            modifier = Modifier.fillMaxSize(),
            textStyle = TextStyle(color = Text, fontSize = 13.sp, lineHeight = 20.sp)
        )
    }
}

@Composable
fun BottomBar() {
    Row(Modifier.fillMaxWidth().height(30.dp).background(Panel2), verticalAlignment = Alignment.CenterVertically) {
        Text("  UTF-8   •   Kotlin   •   Ready", color = Muted, fontSize = 10.sp)
    }
}

@Composable
fun AiPanel(prompt: String, reply: String, onPrompt: (String) -> Unit, onAsk: () -> Unit) {
    Column(
        Modifier.width(300.dp).fillMaxHeight().background(Panel).padding(12.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.AutoAwesome, null, tint = Accent, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(7.dp))
            Text("AI ASSISTANT", color = Text, fontSize = 13.sp)
        }
        Spacer(Modifier.height(12.dp))
        Text(reply, color = Muted, fontSize = 12.sp)
        Spacer(Modifier.weight(1f))
        OutlinedTextField(
            value = prompt,
            onValueChange = onPrompt,
            modifier = Modifier.fillMaxWidth(),
            placeholder = { Text("Ask about your code…") },
            minLines = 3
        )
        Spacer(Modifier.height(8.dp))
        Button(onClick = onAsk, modifier = Modifier.fillMaxWidth()) {
            Icon(Icons.Default.AutoAwesome, null, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(6.dp))
            Text("Ask AI")
        }
    }
}
