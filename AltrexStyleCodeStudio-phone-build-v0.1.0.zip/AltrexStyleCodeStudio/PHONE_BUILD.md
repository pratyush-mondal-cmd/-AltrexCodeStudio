# ফোন থেকেই APK বানানোর পদ্ধতি

1. GitHub-এ একটি নতুন repository তৈরি করুন।
2. এই project-এর সব ফাইল upload করুন।
3. `.github/workflows/build-apk.yml` ফাইলটিও অবশ্যই upload হয়েছে নিশ্চিত করুন।
4. GitHub repository > Actions > `Build Android APK` > `Run workflow` চাপুন।
5. Build শেষ হলে workflow-এর run খুলে Artifacts থেকে `Code-Studio-debug-apk` ZIP download করুন।
6. ZIP খুলে `app-debug.apk` ফোনে install করুন।
7. Android যদি অনুমতি চায়, আপনার ব্যবহৃত browser/file manager-এর জন্য "Install unknown apps" অনুমতি দিন এবং আবার APK খুলুন।

নোট: এটি debug APK। পরের ধাপে release signing যোগ করা যাবে।
